<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReservationController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function calculate(Request $request)
    {
        $request->validate([
            'flight' => 'required',
            'hotel' => 'required',
            'passengers' => 'required|integer|min:1',
            'stayDuration' => 'required|integer|min:1',
        ]);

        $flightPrice = $request->flight === "vuelo1" ? 200 : 250;
        $hotelPricePerNight = $request->hotel === "hotel1" ? 100 : 150;
        $totalAmount = ($flightPrice * $request->passengers) + ($hotelPricePerNight * $request->stayDuration * $request->passengers);

        return redirect()->route('reservar.index')->with([
            'summary' => [
                'selectedFlight' => $request->flight,
                'selectedHotel' => $request->hotel,
                'totalPassengers' => $request->passengers,
                'totalNights' => $request->stayDuration,
                'totalAmount' => $totalAmount,
            ],
            'message' => 'Total calculado correctamente',
            'type' => 'success'
        ]);
    }

    public function confirm(Request $request)
    {
        // Lógica para confirmar la compra
    }

    public function cancel(Request $request)
    {
        // Lógica para cancelar la reservación
    }
}
