<div class="container mt-4"> 

<div class="alert alert-{{ $tipo }}" role="alert">
{{ $slot }}
</div>
</div>