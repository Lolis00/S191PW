



<?php $__env->startSection('titulo', 'Clientes'); ?>


  <?php $__env->startSection('contenido'); ?>


<div class="container mt-5 col-md-8">

<div class="card text-justify font-monospace">
    <div class="card-header fs-5 text-primary">
        Zuñiga Perruquia Maria Dolores
        
    </div>

    <div class="card-body">
        <h5 class="fw-bold"> lolis.30@outlook.com</h5>
        <h5 class="fw-medium"> 4421263765 </h5>
        <p class="card-text fw-lihgter"></p>
    </div>

    <div class="card-footer text-muted">
        <button type="submit" class="btn btn-warning btn-sm"><?php echo e(__('Actualizar')); ?></button>
        <button type="submit" class="btn btn-danger btn-sm"><?php echo e(__('Eliminar')); ?></button>
    </div>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\S191PW\pruebalaravel\resources\views/clientes.blade.php ENDPATH**/ ?>