<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inicio</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

    <style>
        body, html {
            height: 100%;
        }
        .full-height {
            height: 100vh;
        }
    </style>
</head>
<body>
    <div class="d-flex flex-column justify-content-center align-items-center full-height">
        
        <h1 class="display-1"><?php echo e(__('Bienvenido Turista!')); ?> </h1>
        <p><?php echo e(__('Presione el botón para iniciar...')); ?> </p>

        <a href="<?php echo e(route('rutacacas')); ?>" class="btn btn-primary"><?php echo e(__('Ir al registro')); ?> </a>
        <a href="<?php echo e(route('rutaconsulta')); ?>" class="btn btn-danger"><?php echo e(__('Consultar Clientes')); ?> </a>
        
</body>
</html><?php /**PATH C:\laragon\www\S191PW\pruebalaravel\resources\views/inicio.blade.php ENDPATH**/ ?>