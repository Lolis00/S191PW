<div class="container mt-4"> 

<div class="card">
  <div class="card-header">
    <?php echo e($encabezado); ?>

  </div>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($titulo); ?></h5>
    <p class="card-text"><?php echo e($slot); ?></p>
    <a href="#" class="btn btn-primary"><?php echo e($textoBoton); ?></a>
  </div>

</div>

</div><?php /**PATH C:\laragon\www\S191PW\pruebalaravel\resources\views/components/card.blade.php ENDPATH**/ ?>