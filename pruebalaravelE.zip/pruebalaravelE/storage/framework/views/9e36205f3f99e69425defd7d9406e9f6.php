<div class="container mt-4"> 

<div class="alert alert-<?php echo e($tipo); ?>" role="alert">
<?php echo e($slot); ?>

</div>
</div><?php /**PATH C:\laragon\www\S191PW\pruebalaravel\resources\views/components/alert.blade.php ENDPATH**/ ?>